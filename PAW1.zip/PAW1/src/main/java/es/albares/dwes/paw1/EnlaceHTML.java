/package es.albares.dwes.paw1;

public class EnlaceHTML {
    private String name;
    private String href;

    public EnlaceHTML(String name, String href) {
        this.name = name;
        this.href = href;
    }

    public String getName() {
        return name;
    }

    public String getHref() {
        return href;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHref(String href) {
        this.href = href;
    }
}
